##' Get list of default prefixes
##'
##' @return List with default prefixes
Get.default.crnd.prefixes<- function( ) {
  env[["qbCDISCprefixes"]]
}
  
