#  dummy test as placeholder
# see http://r-pkgs.had.co.nz/tests.html
expect_equal(2+2, 4)
