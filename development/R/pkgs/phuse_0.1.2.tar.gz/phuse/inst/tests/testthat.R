library(testthat)
library(phuse)

test_check("phuse")
