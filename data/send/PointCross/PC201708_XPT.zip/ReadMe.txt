PC201708 is synthetic SEND 3.0 dataset created by PointCross Inc. 

This study may be freely used for development of tools, applications scripts etc.

For more detials about this study please refer NSDRG (PC201708_draft_nsdrg.docx) and define.pdf

This study can be visualized in MySEND freely available from (http://info.pointcrosslifesciences.com/mysend) 
or using XBIOM NonClinical (http://www.pointcrosslifesciences.com/index.php/xbiom-platform)

