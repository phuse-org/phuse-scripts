Notes:

1. You should only need to change the top_dir macro variable in each SAS program (except for any in the utilities folder). 
	a. The MedDRA_at_a_Glance SAS program requires inputting the meddra vesion and path to that version's SAS datasets
2. Put the required datzets in the data folder or change the studypath macro variable
3. The outputs will go into the Outputs folder by default.
4. The scripts require a recent version of SAS/Stat and a running SAS PC Files Server process that matches the version of SAS running the code. 